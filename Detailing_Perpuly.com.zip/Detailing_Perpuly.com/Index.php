<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Detailed Perpuly</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background: linear-gradient(135deg, #0d6efd, #000000); /* 🔵 azul + negro */
            color: white;
        }

        .card{
            background-color: rgba(20, 20, 20, 0.95);
            border-radius: 15px;
            border: 1px solid #0d6efd;
        }

        .titulo{
            color: rgb(243, 245, 248);
            font-weight: bold;
        }

        .subtitulo{
            color: #cccccc;
        }

        /* 🔵 INPUTS AZULES */
        .form-control{
            background-color: #0d6efd;
            border: none;
            color: white;
        }

        .form-control::placeholder{
            color: #e0e0e0;
        }

        .form-control:focus{
            background-color: #0b5ed7;
            color: white;
            box-shadow: none;
        }

        label{
            color: #e3e6ea;
            font-weight: bold;
        }

        .btn-custom{
            background: linear-gradient(45deg, #0d6efd, #ff0000);
            border: none;
            color: white;
            font-weight: bold;
        }

        .btn-custom:hover{
            background: linear-gradient(45deg, #0b5ed7, #cc0000);
        }

        .logo{
            width: 80px;
            margin-top: 10px;
        }
    </style>
</head>

<body>

<main class="container py-5">
    <div class="row justify-content-center">
        <div class="col-12 col-md-6 col-lg-4">

            <div class="text-center mb-4">
                <h1 class="titulo">DETAILED PERPULY</h1>
                <p class="subtitulo">Acceso al sistema</p>
            </div>

            <div class="card shadow">
                <div class="card-body p-4">

                    <?php if(isset($_GET['error'])): ?>
                        <div class="alert alert-danger text-center">
                            Acceso denegado
                        </div>
                    <?php endif; ?>

                    <form action="Login.php" method="post">

                        <div class="mb-3">
                            <label>Correo Electronico</label>
                            <input type="text" name="correo" class="form-control" placeholder="******" required>
                        </div>

                        <div class="mb-3">
                            <label>Contraseña</label>
                            <input type="password" name="password" class="form-control" placeholder="********" required>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-custom">
                                Iniciar Sesión
                            </button>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</main>

</body>
</html>