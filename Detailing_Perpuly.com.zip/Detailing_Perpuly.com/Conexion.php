<?php

$host = "fdb1032.awardspace.net";
$usuario = "4765355_detailing";
$pass = "Perpuly2026";
$db = "4765355_detailing";
$port = "3306";

$connect = new mysqli($host, $usuario, $pass, $db, $port);

if ($connect->connect_error) {
    die("Error de conexión: " . $connect->connect_error);
}

$connect->set_charset("utf8mb4");

?>