<?php

require_once("Conexion.php");

$mensaje = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $nombre = $_POST['nombre'];

    $correo = $_POST['correo'];

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $rol = "cliente";

    /* VALIDAR CORREO */
    $sql =
    "SELECT id FROM usuarios
    WHERE correo = ?";

    $stmt = $connect->prepare($sql);

    $stmt->bind_param("s", $correo);

    $stmt->execute();

    $resultado = $stmt->get_result();

    if($resultado->num_rows > 0){

        $mensaje =
        "Este correo ya está registrado";

    }else{

        /* INSERTAR */
        $sql =
        "INSERT INTO usuarios
        (nombre,correo,password,rol)

        VALUES (?,?,?,?)";

        $stmt =
        $connect->prepare($sql);

        $stmt->bind_param(
            "ssss",
            $nombre,
            $correo,
            $password,
            $rol
        );

        if($stmt->execute()){

            echo "
            <script>

            alert(
            'Usuario registrado correctamente'
            );

            window.location='paquetes.php';

            </script>
            ";

            exit;

        }else{

            $mensaje =
            'Error al registrar usuario';

        }

    }

}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro | Detailed Perpuly</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body{
            background: linear-gradient(135deg, #0d6efd, #000000);
            color: white;
        }

        .card{
            background-color: rgba(20, 20, 20, 0.95);
            border-radius: 15px;
            border: 1px solid #0d6efd;
        }

        .titulo{
            color: white;
            font-weight: bold;
        }

        .subtitulo{
            color: #cccccc;
        }

        .form-control{
            background-color: #0d6efd;
            border: none;
            color: white;
        }

        .form-control::placeholder{
            color: #e0e0e0;
        }

        .form-control:focus{
            background-color: #0b5ed7;
            color: white;
            box-shadow: none;
        }

        label{
            color: #e3e6ea;
            font-weight: bold;
        }

        .btn-custom{
            background: linear-gradient(45deg, #0d6efd, #ff0000);
            border: none;
            color: white;
            font-weight: bold;
        }

        .btn-custom:hover{
            background: linear-gradient(45deg, #0b5ed7, #cc0000);
        }

        a{
            color: #0d6efd;
            text-decoration: none;
        }

        a:hover{
            color: #66b2ff;
        }

    </style>

</head>

<body>

<main class="container py-5">

    <div class="row justify-content-center">

        <div class="col-12 col-md-6 col-lg-4">

            <div class="text-center mb-4">
                <h1 class="titulo">DETAILED PERPULY</h1>
                <p class="subtitulo">Registro de nuevos clientes</p>
            </div>

            <div class="card shadow">

                <div class="card-body p-4">

                    <?php if($mensaje != ""): ?>

                        <div class="alert alert-info text-center">
                            <?php echo $mensaje; ?>
                        </div>

                    <?php endif; ?>

                    <form method="POST">

                        <div class="mb-3">
                            <label>Nombre</label>
                            <input type="text"
                                   name="nombre"
                                   class="form-control"
                                   placeholder="Tu nombre"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label>Correo</label>
                            <input type="email"
                                   name="correo"
                                   class="form-control"
                                   placeholder="correo@ejemplo.com"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label>Contraseña</label>
                            <input type="password"
                                   name="password"
                                   class="form-control"
                                   placeholder="********"
                                   required>
                        </div>

                        <div class="d-grid">

                            <button type="submit" class="btn btn-custom">
                                Registrarse
                            </button>

                        </div>

                    </form>

                    <div class="text-center mt-3">

                        ¿Ya tienes cuenta?

                        <a href="login.php">
                            Iniciar sesión
                        </a>

                    </div>

                </div>

            </div>

        </div>

    </div>

</main>

</body>
</html>