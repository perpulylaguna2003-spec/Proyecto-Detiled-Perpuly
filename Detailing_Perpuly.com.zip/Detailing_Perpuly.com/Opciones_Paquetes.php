<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit;
}

require_once("Conexion.php");

$mensaje = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $paquete_id = $_POST['paquete_id'];
    $nombre_opcion = $_POST['nombre_opcion'];
    $precio = $_POST['precio'];

    $sql = "INSERT INTO paquete_opciones (paquete_id, nombre_opcion, precio, estado)
            VALUES ('$paquete_id', '$nombre_opcion', '$precio', 'Activo')";

    if($connect->query($sql)){
        $mensaje = "Opción agregada correctamente.";
    }else{
        $mensaje = "Error al guardar la opción: " . $connect->error;
    }
}

$paquetes = $connect->query("SELECT id, nombre FROM paquete WHERE estado = 'Activo' ORDER BY nombre ASC");
$opciones = $connect->query("
    SELECT po.id, p.nombre AS paquete, po.nombre_opcion, po.precio, po.estado
    FROM paquete_opciones po
    INNER JOIN paquete p ON po.paquete_id = p.id
    ORDER BY po.id DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Administrar Opciones</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#000;
    color:white;
    font-family:Arial;
}

.contenedor{
    max-width:1000px;
    margin:auto;
    padding:30px;
}

.card-custom{
    background:#111;
    border:1px solid #0d6efd;
    border-radius:15px;
    padding:25px;
}

.form-control, .form-select{
    background:#1a1a1a;
    color:white;
    border:1px solid #0d6efd;
}

.form-control:focus, .form-select:focus{
    background:#1a1a1a;
    color:white;
}

.table{
    margin-top:30px;
}
</style>
</head>

<body>

<div class="contenedor">

<h2 class="text-center text-primary mb-4">Administrar Opciones de Paquetes</h2>

<div class="card-custom mb-4">

<?php if($mensaje != ""){ ?>
    <div class="alert alert-success">
        <?= $mensaje ?>
    </div>
<?php } ?>

<form method="POST">

    <label>Paquete</label>
    <select name="paquete_id" class="form-select mb-3" required>
        <option value="">Selecciona un paquete</option>
        <?php while($p = $paquetes->fetch_assoc()){ ?>
            <option value="<?= $p['id'] ?>">
                <?= htmlspecialchars($p['nombre']) ?>
            </option>
        <?php } ?>
    </select>

    <label>Nombre de la opción</label>
    <input type="text" name="nombre_opcion" class="form-control mb-3" placeholder="Ejemplo: Par de focos" required>

    <label>Precio</label>
    <input type="number" name="precio" class="form-control mb-3" step="0.01" placeholder="Ejemplo: 280" required>

    <button type="submit" class="btn btn-primary">
        Guardar opción
    </button>

    <a href="paquetes.php" class="btn btn-secondary">
        Regresar
    </a>

</form>

</div>

<h4 class="text-primary">Opciones registradas</h4>

<table class="table table-dark table-bordered table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Paquete</th>
            <th>Opción</th>
            <th>Precio</th>
            <th>Estado</th>
        </tr>
    </thead>

    <tbody>
        <?php while($op = $opciones->fetch_assoc()){ ?>
            <tr>
                <td><?= $op['id'] ?></td>
                <td><?= htmlspecialchars($op['paquete']) ?></td>
                <td><?= htmlspecialchars($op['nombre_opcion']) ?></td>
                <td>$<?= number_format($op['precio'], 2) ?></td>
                <td><?= htmlspecialchars($op['estado']) ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>

</div>

</body>
</html>