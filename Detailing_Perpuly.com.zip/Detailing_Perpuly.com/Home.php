
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Detailed Perpuly</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#000;
    color:white;
    overflow-x:hidden;
    font-family:Arial, sans-serif;
}

.lado{
    position:fixed;
    top:0;
    width:10%;
    height:100%;
    z-index:-1;
    background:linear-gradient(180deg, red, blue, black);
}

.lado-izq{left:0;}
.lado-der{right:0;}

.contenedor{
    max-width:1100px;
    margin:auto;
    padding:20px;
}

.titulo{
    text-align:center;
    font-size:42px;
    font-weight:bold;
    color:white;
    margin-top:25px;
}

.subtitulo{
    text-align:center;
    color:#ddd;
    margin-bottom:25px;
}

.imagen-central{
    width:60%;
    max-height:350px;
    object-fit:cover;
    margin:auto;
    display:block;
    border-radius:20px;
    border:3px solid #0d6efd;
    box-shadow:0 0 20px rgba(13,110,253,.5);
}

.btn-custom{
    background:linear-gradient(45deg, #0d6efd, red);
    color:white;
    font-weight:bold;
    border:none;
}

.btn-custom:hover{
    background:linear-gradient(45deg, red, #0d6efd);
    color:white;
}

.info{
    background:#111;
    padding: 20px;
    margin-top:20px;
    text-align:center;
    border-top:1px solid #0d6efd;
}

.carousel{
    background:#111;
    border-bottom:px solid #0d6efd;
}

.btn-admin{
    position:fixed;
    right:20px;
    bottom:20px;
    background:#0d6efd;
    color:white;
    padding:10px 18px;
    border-radius:30px;
    text-decoration:none;
    font-weight:bold;
    box-shadow:0 0 15px #0d6efd;
}

.btn-admin:hover{
    background:red;
    color:white;
}
</style>
</head>

<body>

<div class="lado lado-izq"></div>
<div class="lado lado-der"></div>

<div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">

        <div class="carousel-item active text-center p-5">
            <h3>Ubicación</h3>
            <p>Encuéntranos fácilmente en Google Maps</p>
            <a href="https://maps.app.goo.gl/zyLWuVVpiLZEXY1k7?g_st=iw" target="_blank" class="btn btn-custom">
                Ver ubicación
            </a>
        </div>

        <div class="carousel-item text-center p-5">
            <h3>Contacto</h3>
            <p>Tel: 613-129-8399</p>
            <p>WhatsApp disponible para cotizaciones y citas</p>
        </div>

        <div class="carousel-item text-center p-5">
            <h3>Servicios</h3>
            <p>Lavado, pulido de focos, tapicería y detallado profesional</p>
        </div>

    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>

    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>

<div class="contenedor">

    <h1 class="titulo">DETAILED PERPULY</h1>

    <p class="subtitulo">
        Más que una lavada, una renovación.
    </p>

    <img src="logo.jpeg" class="imagen-central" alt="Detailed Perpuly">

    <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">


        <a href="Trabajos.php" class="btn btn-custom btn-lg">
            Trabajos Realizados
        </a>

        <a href="Index.php" class="btn btn-custom btn-lg">
            Iniciar Sesión
        </a>

        <a href="Registro.php" class="btn btn-custom btn-lg">
            Registrarme
        </a>

    </div>

</div>

<div class="info">
    <h3>Sobre Nosotros</h3>
    <p>
        En Detailed Perpuly nos enfocamos en el cuidado, limpieza y renovación de vehículos,
        ofreciendo servicios de calidad con atención al detalle.
    </p>

    <p>Calidad | Profesionalismo | Detalle</p>
</div>

<a href="Index.php" class="btn-admin">
</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>