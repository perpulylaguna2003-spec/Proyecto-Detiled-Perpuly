<?php
session_start();
date_default_timezone_set('America/Mazatlan');

require_once "Conexion.php";

$paquete = $_POST['paquete'] ?? '';
$opcion = $_POST['opcion'] ?? '';
$precio = $_POST['precio'] ?? 0;
$fecha = $_POST['fecha'] ?? '';
$hora = $_POST['hora'] ?? '';

$usuario_id = $_SESSION['id'] ?? 0;
$nombre_usuario = $_SESSION['usuario'] ?? 'Cliente';
$estado = "Agendada";

if(empty($paquete) || empty($opcion) || empty($fecha) || empty($hora)){
    echo "<script>alert('Selecciona paquete, opción, fecha y hora'); window.history.back();</script>";
    exit;
}

$fechaMinima = date('Y-m-d', strtotime('+1 day'));

if($fecha < $fechaMinima){
    echo "<script>
        alert('Solo puedes agendar citas con al menos un día de anticipación.');
        window.history.back();
    </script>";
    exit;
}

/* OBTENER DURACIÓN DESDE LA TABLA paquete */
$sqlDuracion = "SELECT duracion FROM paquete WHERE nombre = ?";
$stmtDuracion = $connect->prepare($sqlDuracion);
$stmtDuracion->bind_param("s", $paquete);
$stmtDuracion->execute();

$resDuracion = $stmtDuracion->get_result();
$datosDuracion = $resDuracion->fetch_assoc();

if(!$datosDuracion){
    echo "<script>alert('No se encontró la duración del paquete'); window.history.back();</script>";
    exit;
}

$duracion = $datosDuracion['duracion'];

$inicio = strtotime($hora);
$fin = strtotime("+$duracion minutes", $inicio);

$hora_inicio = date("H:i:s", $inicio);
$hora_fin = date("H:i:s", $fin);

/* VALIDAR CHOQUES */
$sql = "SELECT * FROM citas 
        WHERE fecha = ?
        AND hora_inicio < ?
        AND hora_fin > ?
        AND estado = 'Agendada'";

$stmt = $connect->prepare($sql);
$stmt->bind_param("sss", $fecha, $hora_fin, $hora_inicio);
$stmt->execute();
$resultado = $stmt->get_result();

if($resultado->num_rows > 0){
    echo "
    <script>
        alert('Ese horario ya está ocupado. Selecciona otra hora.');
        window.history.back();
    </script>";
    exit;
}

/* GUARDAR CITA */
$sql = "INSERT INTO citas(paquete, opcion, precio, fecha, hora_inicio, hora_fin, usuario_id, nombre_usuario, estado)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $connect->prepare($sql);
$stmt->bind_param(
    "ssdsssiss",
    $paquete,
    $opcion,
    $precio,
    $fecha,
    $hora_inicio,
    $hora_fin,
    $usuario_id,
    $nombre_usuario,
    $estado
);

if($stmt->execute()){
    echo "
    <script>
        alert('Cita registrada exitosamente');
        window.location='paquetes.php';
    </script>";
}else{
    echo "
    <script>
        alert('Error al guardar la cita');
        window.history.back();
    </script>";
}
?>