<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Trabajos Realizados | Detailed Perpuly</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#000;
    color:white;
    font-family:Arial;
}

.contenedor{
    max-width:1200px;
    margin:auto;
    padding:25px;
}

.titulo{
    text-align:center;
    color:#0d6efd;
    font-weight:bold;
    margin-bottom:30px;
}

.card-trabajo{
    background:#111;
    border:1px solid #0d6efd;
    border-radius:15px;
    overflow:hidden;
    height:100%;
    box-shadow:0 0 15px rgba(13,110,253,.3);
}

.card-trabajo img{
    width:100%;
    height:230px;
    object-fit:cover;
}

.card-body{
    padding:20px;
}

.btn-custom{
    background:linear-gradient(45deg,#0d6efd,red);
    color:white;
    border:none;
    font-weight:bold;
}

.btn-custom:hover{
    color:white;
    background:linear-gradient(45deg,red,#0d6efd);
}
</style>
</head>

<body>

<div class="contenedor">

<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="Home.php" class="btn btn-custom">Regresar al inicio</a>
    <a href="paquetes.php" class="btn btn-custom">Agendar cita</a>
</div>

<h2 class="titulo">Trabajos Realizados</h2>

<div class="row g-4">

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabajo5.jpeg" alt="Trabajo realizado 1">
            <div class="card-body">
                <h4>Pulido de focos</h4>
                <p>Restauración de claridad y brillo en faros opacos.</p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabajo6.jpeg" alt="Trabajo realizado 2">
            <div class="card-body">
                <h4>Detallado exterior</h4>
                <p>Limpieza profunda, brillo y protección para la pintura.</p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabajo4.jpeg" alt="Trabajo realizado 3">
            <div class="card-body">
                <h4>Limpieza de tapicería</h4>
                <p>Lavado y renovación de interiores, asientos y telas.</p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabajo3.jpeg" alt="Trabajo realizado 4">
            <div class="card-body">
                <h4>Lavado completo</h4>
                <p>Servicio de limpieza interior y exterior del vehículo.</p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabjo2.jpeg" alt="Trabajo realizado 5">
            <div class="card-body">
                <h4>Detallado interior</h4>
                <p>Cuidado de tablero, plásticos, alfombras y vestiduras.</p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card-trabajo">
            <img src="Trabajo1.jpeg" alt="Trabajo realizado 6">
            <div class="card-body">
                <h4>Limpieza de Sales,Colchones.</h4>
                <p>Servicio profesional para mejorar la apariencia general.</p>
            </div>
        </div>
    </div>

</div>

</div>

</body>
</html>