<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit;
}

if($_SESSION['rol'] != 'admin'){
    header("Location: Paquetes.php");
    exit;
}

require_once("Conexion.php");

$mensaje = "";

/* AGREGAR PAQUETE */
if(isset($_POST['agregar_paquete'])){
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $duracion = $_POST['duracion'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO paquete(nombre, descripcion, duracion, estado) VALUES (?, ?, ?, ?)";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("ssis", $nombre, $descripcion, $duracion, $estado);

    if($stmt->execute()){
        $mensaje = "Paquete agregado correctamente.";
    }
}

/* ACTUALIZAR PAQUETE */
if(isset($_POST['actualizar_paquete'])){
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $duracion = $_POST['duracion'];
    $estado = $_POST['estado'];

    $sql = "UPDATE paquete SET nombre=?, descripcion=?, duracion=?, estado=? WHERE id=?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("ssisi", $nombre, $descripcion, $duracion, $estado, $id);

    if($stmt->execute()){
        $mensaje = "Paquete actualizado correctamente.";
    }
}

/* CAMBIAR ESTADO PAQUETE */
if(isset($_GET['cambiar_estado_paquete'])){
    $id = $_GET['cambiar_estado_paquete'];
    $estadoActual = $_GET['estado'];
    $nuevoEstado = ($estadoActual == "Activo") ? "Inactivo" : "Activo";

    $sql = "UPDATE paquete SET estado=? WHERE id=?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("si", $nuevoEstado, $id);
    $stmt->execute();

    $mensaje = "Estado del paquete actualizado.";
}

/* CAMBIAR ESTADO DE CITA */
if(isset($_GET['cambiar_estado_cita'])){
    $id = $_GET['cambiar_estado_cita'];
    $nuevoEstado = $_GET['estado'] ?? '';

    if($nuevoEstado == 'Realizada' || $nuevoEstado == 'Cancelada' || $nuevoEstado == 'Agendada'){
        $sql = "UPDATE citas SET estado=? WHERE id=?";
        $stmt = $connect->prepare($sql);
        $stmt->bind_param("si", $nuevoEstado, $id);
        $stmt->execute();

        $mensaje = "Estado de la cita actualizado correctamente.";
    }
}

/* BLOQUEAR / DESBLOQUEAR USUARIO */
if(isset($_GET['bloquear_usuario'])){
    $id = $_GET['bloquear_usuario'];
    $estadoActual = $_GET['estado'];
    $nuevoEstado = ($estadoActual == "Activo") ? "Bloqueado" : "Activo";

    $sql = "UPDATE usuarios SET estado=? WHERE id=?";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("si", $nuevoEstado, $id);
    $stmt->execute();

    $mensaje = "Estado del usuario actualizado.";
}

/* CONSULTAR PAQUETES */
$busqueda = "";

if(isset($_GET['buscar']) && $_GET['buscar'] != ""){
    $busqueda = $_GET['buscar'];
    $like = "%$busqueda%";

    $sql = "SELECT * FROM paquete WHERE nombre LIKE ? OR descripcion LIKE ? ORDER BY id DESC";
    $stmt = $connect->prepare($sql);
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $paquetes = $stmt->get_result();
}else{
    $paquetes = $connect->query("SELECT * FROM paquete ORDER BY id DESC");
}

/* CONSULTAR USUARIOS */
$usuarios = $connect->query("SELECT * FROM usuarios ORDER BY id DESC");

/* CONSULTAR CITAS */
$citas = $connect->query("SELECT * FROM citas ORDER BY fecha DESC, hora_inicio DESC");

?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Administrador | Detailed Perpuly</title>

<style>
*{box-sizing:border-box;}

body{
    margin:0;
    font-family:Arial, sans-serif;
    background:#080808;
    color:white;
}

.header{
    background:#0d6efd;
    padding:20px;
    text-align:center;
    font-size:24px;
    font-weight:bold;
}

.container{
    max-width:1200px;
    margin:auto;
    padding:25px;
}

.top-bar{
    display:flex;
    justify-content:flex-end;
    margin-bottom:15px;
}

.mensaje{
    background:#198754;
    padding:12px;
    border-radius:8px;
    margin-bottom:15px;
    text-align:center;
    font-weight:bold;
}

.card{
    background:#111;
    border:1px solid #0d6efd;
    border-radius:15px;
    padding:20px;
    margin-bottom:25px;
    box-shadow:0 0 15px rgba(13,110,253,.3);
}

h2{
    color:#0d6efd;
    margin-top:0;
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));
    gap:12px;
}

input, textarea, select{
    width:100%;
    padding:10px;
    border-radius:8px;
    border:1px solid #333;
    background:#1b1b1b;
    color:white;
}

textarea{resize:none;}

button, .btn{
    padding:9px 13px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    text-decoration:none;
    color:white;
    display:inline-block;
    font-size:14px;
}

.btn-azul{background:#0d6efd;}
.btn-verde{background:#198754;}
.btn-rojo{background:#dc3545;}
.btn-gris{background:#6c757d;}
.btn-warning{background:#ffc107;color:black;}

table{
    width:100%;
    border-collapse:collapse;
    background:#111;
    border-radius:10px;
    overflow:hidden;
}

th{
    background:#0d6efd;
    padding:12px;
}

td{
    padding:12px;
    border-bottom:1px solid #333;
    text-align:center;
}

.activo{
    color:#00ff99;
    font-weight:bold;
}

.inactivo, .bloqueado, .cancelada{
    color:#ff4d4d;
    font-weight:bold;
}

.agendada{
    color:#ffc107;
    font-weight:bold;
}

.realizada{
    color:#00ff99;
    font-weight:bold;
}

.resumen{
    font-size:24px;
    color:#00ff99;
    font-weight:bold;
}

.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.75);
    z-index:1000;
}

.modal-content{
    background:#111;
    border:1px solid #0d6efd;
    width:420px;
    max-width:95%;
    margin:8% auto;
    padding:25px;
    border-radius:15px;
}

.footer{
    text-align:center;
    color:#aaa;
    padding:15px;
}
</style>
</head>

<body>

<div class="header">
    Panel de Administración - Detailed Perpuly
</div>

<div class="container">

<div class="top-bar">
    <a href="logout.php" class="btn btn-rojo">Cerrar Sesión</a>
</div>

<?php if($mensaje != ""){ ?>
    <div class="mensaje"><?= $mensaje ?></div>
<?php } ?>

<div class="card">
    <h2>Agregar nuevo paquete</h2>

    <form method="POST" class="form-grid">
        <input type="text" name="nombre" placeholder="Nombre del paquete" required>

        <textarea name="descripcion" placeholder="Descripción del paquete" required></textarea>

        <input type="number" name="duracion" placeholder="Duración en minutos. Ej: 120" required>

        <select name="estado">
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
        </select>

        <button type="submit" name="agregar_paquete" class="btn-azul">
            Agregar paquete
        </button>
    </form>
</div>

<div class="card">
    <h2>Paquetes registrados</h2>

    <form method="GET" style="margin-bottom:15px;">
        <input type="text" name="buscar" placeholder="Buscar paquete..." value="<?= htmlspecialchars($busqueda) ?>">
        <br><br>
        <button type="submit" class="btn-azul">Buscar</button>
        <a href="Admin.php" class="btn btn-gris">Limpiar</a>
    </form>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Duración</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>

        <?php if($paquetes && $paquetes->num_rows > 0){ ?>
            <?php while($row = $paquetes->fetch_assoc()){ 
                $estadoPaquete = $row['estado'] ?? 'Activo';
            ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nombre']) ?></td>
                <td><?= htmlspecialchars($row['descripcion']) ?></td>
                <td><?= htmlspecialchars($row['duracion']) ?> min</td>
                <td class="<?= strtolower($estadoPaquete) ?>"><?= $estadoPaquete ?></td>
                <td>
                    <button class="btn-verde" onclick='editarPaquete(<?= json_encode($row) ?>)'>Editar</button>

                    <a class="btn-warning"
                       href="?cambiar_estado_paquete=<?= $row['id'] ?>&estado=<?= $estadoPaquete ?>">
                       <?= $estadoPaquete == "Activo" ? "Inactivar" : "Activar" ?>
                    </a>
                </td>
            </tr>
            <?php } ?>
        <?php } else { ?>
            <tr>
                <td colspan="6">No se encontraron paquetes.</td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="card">
    <h2>Usuarios registrados</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Correo</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Acción</th>
        </tr>

        <?php if($usuarios && $usuarios->num_rows > 0){ ?>
            <?php while($user = $usuarios->fetch_assoc()){ 
                $estadoUsuario = $user['estado'] ?? 'Activo';
            ?>
            <tr>
                <td><?= $user['id'] ?></td>
                <td><?= htmlspecialchars($user['nombre']) ?></td>
                <td><?= htmlspecialchars($user['correo']) ?></td>
                <td><?= htmlspecialchars($user['rol']) ?></td>
                <td class="<?= strtolower($estadoUsuario) ?>"><?= $estadoUsuario ?></td>
                <td>
                    <a class="<?= $estadoUsuario == 'Activo' ? 'btn-rojo' : 'btn-verde' ?>"
                       href="?bloquear_usuario=<?= $user['id'] ?>&estado=<?= $estadoUsuario ?>"
                       onclick="return confirm('¿Seguro que deseas cambiar el estado de este usuario?')">
                       <?= $estadoUsuario == "Activo" ? "Bloquear" : "Desbloquear" ?>
                    </a>
                </td>
            </tr>
            <?php } ?>
        <?php } else { ?>
            <tr>
                <td colspan="6">No hay usuarios registrados.</td>
            </tr>
        <?php } ?>
    </table>
</div>

<div class="card">
    <h2>Citas registradas</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Cliente</th>
            <th>Paquete</th>
            <th>Opción</th>
            <th>Precio</th>
            <th>Fecha</th>
            <th>Hora inicio</th>
            <th>Hora fin</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>

        <?php if($citas && $citas->num_rows > 0){ ?>
            <?php while($cita = $citas->fetch_assoc()){ ?>
            <tr>
                <td><?= $cita['id'] ?></td>
                <td><?= htmlspecialchars($cita['nombre_usuario'] ?? 'Cliente') ?></td>
                <td><?= htmlspecialchars($cita['paquete']) ?></td>
                <td><?= htmlspecialchars($cita['opcion'] ?? '') ?></td>
                <td>$<?= number_format($cita['precio'], 2) ?></td>
                <td><?= $cita['fecha'] ?></td>
                <td><?= $cita['hora_inicio'] ?></td>
                <td><?= $cita['hora_fin'] ?></td>
                <?php $estadoCita = $cita['estado'] ?? 'Agendada'; ?>
                <td class="<?= strtolower($estadoCita) ?>"><?= htmlspecialchars($estadoCita) ?></td>
                <td>
                    <a class="btn-verde"
                       href="?cambiar_estado_cita=<?= $cita['id'] ?>&estado=Realizada"
                       onclick="return confirm('¿Marcar esta cita como realizada?')">
                       Realizada
                    </a>

                    <a class="btn-rojo"
                       href="?cambiar_estado_cita=<?= $cita['id'] ?>&estado=Cancelada"
                       onclick="return confirm('¿Marcar esta cita como cancelada?')">
                       Cancelada
                    </a>
                </td>
            </tr>
            <?php } ?>
        <?php } else { ?>
            <tr>
                <td colspan="10">No hay citas registradas.</td>
            </tr>
        <?php } ?>
    </table>
</div>

</div>

<div class="footer">
    Detailed Perpuly - Administración de paquetes, usuarios, citas y ventas
</div>

<div class="modal" id="modalEditar">
    <div class="modal-content">
        <h2>Editar paquete</h2>

        <form method="POST">
            <input type="hidden" name="id" id="edit_id">

            <label>Nombre</label>
            <input type="text" name="nombre" id="edit_nombre" required>

            <label>Descripción</label>
            <textarea name="descripcion" id="edit_descripcion" required></textarea>

            <label>Duración en minutos</label>
            <input type="number" name="duracion" id="edit_duracion" required>

            <label>Estado</label>
            <select name="estado" id="edit_estado">
                <option value="Activo">Activo</option>
                <option value="Inactivo">Inactivo</option>
            </select>

            <br><br>

            <button type="submit" name="actualizar_paquete" class="btn-verde">
                Guardar cambios
            </button>

            <button type="button" onclick="cerrarModal()" class="btn-gris">
                Cancelar
            </button>
        </form>
    </div>
</div>

<script>
function editarPaquete(paquete){
    document.getElementById("modalEditar").style.display = "block";

    document.getElementById("edit_id").value = paquete.id;
    document.getElementById("edit_nombre").value = paquete.nombre;
    document.getElementById("edit_descripcion").value = paquete.descripcion;
    document.getElementById("edit_duracion").value = paquete.duracion;
    document.getElementById("edit_estado").value = paquete.estado ?? "Activo";
}

function cerrarModal(){
    document.getElementById("modalEditar").style.display = "none";
}

window.onclick = function(e){
    let modal = document.getElementById("modalEditar");
    if(e.target == modal){
        cerrarModal();
    }
}
</script>

</body>
</html>
