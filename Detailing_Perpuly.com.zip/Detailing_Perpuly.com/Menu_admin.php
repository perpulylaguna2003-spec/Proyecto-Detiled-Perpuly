<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Menú Administrador | Detailed Perpuly</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#000;
    color:white;
    font-family:Arial;
}

.contenedor{
    max-width:900px;
    margin:auto;
    padding:40px;
    text-align:center;
}

.card-menu{
    background:#111;
    border:1px solid #0d6efd;
    border-radius:15px;
    padding:30px;
    margin-top:30px;
    box-shadow:0 0 15px #0d6efd;
}

.btn-menu{
    width:260px;
    padding:15px;
    margin:15px;
    font-size:18px;
    font-weight:bold;
    border-radius:10px;
}
</style>
</head>

<body>

<div class="contenedor">

    <h2 class="text-primary">Panel Principal del Administrador</h2>
    <p>Selecciona el módulo que deseas administrar</p>

    <div class="card-menu">

        <a href="Admin.php" class="btn btn-primary btn-menu">
            Admin General
        </a>

        <a href="Opciones_Paquetes.php" class="btn btn-success btn-menu">
            Paquete Opciones
        </a>
        <a href="paquetes.php" class="btn btn-success btn-menu">
            Paquetes
        </a>

        <a href="logout.php" class="btn btn-danger btn-menu">
            Cerrar Sesión
        </a>

    </div>

</div>

</body>
</html>