<?php
require_once 'Conexion.php';

/* ADMIN */
$nombre = "admin";
$correo = "admin@detailed.com";
$password = password_hash("12345", PASSWORD_DEFAULT);
$rol = "admin";
$estado = "Activo";

$insert = $connect->prepare("
INSERT INTO usuarios(nombre, correo, password, rol, estado)
VALUES(?,?,?,?,?)
");

$insert->bind_param("sssss", $nombre, $correo, $password, $rol, $estado);
$insert->execute();

echo "Usuarios creados correctamente";
?>