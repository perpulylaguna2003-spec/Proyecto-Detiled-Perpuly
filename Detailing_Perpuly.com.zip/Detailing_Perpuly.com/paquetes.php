<?php
session_start();

if(!isset($_SESSION['usuario'])){
    header("Location: Index.php");
    exit;
}

require_once("Conexion.php");

$paquetes = $connect->query("SELECT * FROM paquete WHERE estado = 'Activo' ORDER BY id ASC");

$usuario_id = $_SESSION['id'] ?? 0;

$stmtHistorial = $connect->prepare("SELECT paquete, opcion, precio, fecha, hora_inicio, hora_fin, estado
                                    FROM citas
                                    WHERE usuario_id = ?
                                    ORDER BY fecha DESC, hora_inicio DESC");
$stmtHistorial->bind_param("i", $usuario_id);
$stmtHistorial->execute();
$historial = $stmtHistorial->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Paquetes | Detailed Perpuly</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<style>
body{background:#000;color:#fff;font-family:Arial;}
.contenedor{max-width:1200px;margin:auto;padding:20px;}
.titulo{text-align:center;color:#0d6efd;font-weight:bold;margin-bottom:30px;}

.card-paquete{
    background:#111;
    border:1px solid #0d6efd;
    border-radius:15px;
    padding:20px;
    height:100%;
    cursor:pointer;
    transition:.3s;
}

.card-paquete:hover{
    transform:scale(1.02);
    box-shadow:0 0 15px #0d6efd;
}

.card-paquete.active{
    border:2px solid red;
    box-shadow:0 0 18px red;
}

.precio{
    color:#00ff99;
    font-size:22px;
    font-weight:bold;
}

.form-control{
    background:#1a1a1a!important;
    color:#fff!important;
    border:1px solid #0d6efd!important;
}

.panel-cita{
    margin-top:40px;
    padding:30px;
    background:#111;
    border-radius:15px;
    border:1px solid #0d6efd;
}

.hora{
    padding:10px 15px;
    border:1px solid #0d6efd;
    margin:5px;
    display:inline-block;
    cursor:pointer;
    border-radius:8px;
}

.hora:hover{background:#0d6efd;}
.hora.active{background:red;border-color:red;}

.btn-custom{
    background:linear-gradient(45deg,#0d6efd,#ff0000);
    color:#fff;
    border:none;
}

/* RESUMEN CITA */
.resumen-cita{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.8);
    z-index:9999;
    justify-content:center;
    align-items:center;
}

.resumen-contenido{
    background:#111;
    border:2px solid #0d6efd;
    border-radius:15px;
    padding:30px;
    width:430px;
    max-width:90%;
    color:white;
    box-shadow:0 0 20px #0d6efd;
}

.resumen-contenido h3{
    color:#0d6efd;
    text-align:center;
    margin-bottom:20px;
}

.resumen-contenido p{
    font-size:16px;
    margin-bottom:10px;
}


/* HISTORIAL */
.historial-citas{
    margin-top:40px;
    padding:25px;
    background:#111;
    border-radius:15px;
    border:1px solid #0d6efd;
}

.historial-citas h4{
    color:#0d6efd;
    text-align:center;
    margin-bottom:20px;
}

.table-dark{
    --bs-table-bg:#111;
    --bs-table-border-color:#0d6efd;
}

.badge-agendada{background:#0d6efd;}
.badge-realizada{background:#198754;}
.badge-cancelada{background:#dc3545;}

</style>
</head>

<body>

<div class="contenedor">

<h2 class="titulo">Nuestros Paquetes</h2>

<div class="d-flex justify-content-end mb-3">
    <a href="logout.php" class="btn btn-danger">
        Cerrar Sesión
    </a>
</div>

<form action="guardar.php" method="POST">

<div class="row g-4">

<?php while($p = $paquetes->fetch_assoc()){ ?>

<div class="col-md-6">
    <div class="card-paquete" onclick='seleccionarPaquete(this, <?= json_encode($p['nombre']) ?>)'>

        <h4><?= htmlspecialchars($p['nombre']) ?></h4>

        <p><?= htmlspecialchars($p['descripcion']) ?></p>

        <?php
    
        $idPaquete = (int)$p['id'];
        $opciones = $connect->query("SELECT * FROM paquete_opciones
                                     WHERE paquete_id = $idPaquete
                                     AND (TRIM(estado) = 'Activo' OR estado IS NULL OR TRIM(estado) = '')
                                     ORDER BY id ASC");
        ?>

        <?php if($opciones && $opciones->num_rows > 0){ ?>
            <select class="form-control mt-3 opcion-paquete"
                    onclick="event.stopPropagation()"
                    onchange="seleccionarOpcion(this)">
                <option value="">Selecciona una opción</option>

                <?php while($op = $opciones->fetch_assoc()){ ?>
                    <option
                        value="<?= $op['id'] ?>"
                        data-precio="<?= $op['precio'] ?>"
                        data-opcion="<?= htmlspecialchars($op['nombre_opcion']) ?>">
                        <?= htmlspecialchars($op['nombre_opcion']) ?> - $<?= number_format($op['precio'], 2) ?>
                    </option>
                <?php } ?>
            </select>
        <?php }else{ ?>
            <div class="alert alert-warning mt-3 mb-0" onclick="event.stopPropagation()">
                Este paquete no tiene opciones registradas para este ID.
            </div>
        <?php } ?>

        <input type="radio" name="paquete" value="<?= htmlspecialchars($p['nombre']) ?>" required hidden>

    </div>
</div>

<?php } ?>

</div>

<input type="hidden" name="precio" id="precio">
<input type="hidden" name="opcion" id="opcion">

<div class="panel-cita">

<h4 class="text-center mb-3">Agenda tu cita</h4>

<div class="row">

<div class="col-md-6">
    <label>Fecha</label>
    <input type="text" id="fecha" name="fecha" class="form-control" required>
</div>

<div class="col-md-6">
    <label>Hora disponible</label>
    <div id="horas"></div>
</div>

</div>

<input type="hidden" name="hora" id="hora">

<br>

<div class="text-center">
    <button type="button" onclick="mostrarResumen()" class="btn btn-custom btn-lg">
        Agendar Cita
    </button>

    <button type="submit" id="enviarCita" style="display:none;"></button>
</div>

</div>

</form>

<div class="historial-citas">
    <h4>Historial de tus citas</h4>

    <?php if($historial && $historial->num_rows > 0){ ?>
        <div class="table-responsive">
            <table class="table table-dark table-bordered table-hover align-middle text-center">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Paquete</th>
                        <th>Opción</th>
                        <th>Precio</th>
                        <th>Horario</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($cita = $historial->fetch_assoc()){ 
                        $estado = $cita['estado'] ?? 'Agendada';
                        $claseEstado = 'badge-agendada';

                        if($estado == 'Realizada'){
                            $claseEstado = 'badge-realizada';
                        }elseif($estado == 'Cancelada'){
                            $claseEstado = 'badge-cancelada';
                        }
                    ?>
                        <tr>
                            <td><?= htmlspecialchars($cita['fecha']) ?></td>
                            <td><?= htmlspecialchars($cita['paquete']) ?></td>
                            <td><?= htmlspecialchars($cita['opcion']) ?></td>
                            <td>$<?= number_format($cita['precio'], 2) ?></td>
                            <td><?= htmlspecialchars(substr($cita['hora_inicio'], 0, 5)) ?> - <?= htmlspecialchars(substr($cita['hora_fin'], 0, 5)) ?></td>
                            <td>
                                <span class="badge <?= $claseEstado ?>">
                                    <?= htmlspecialchars($estado) ?>
                                </span>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    <?php }else{ ?>
        <div class="alert alert-info text-center mb-0">
            Todavía no tienes citas registradas.
        </div>
    <?php } ?>
</div>


</div>

<div id="resumenCita" class="resumen-cita">
    <div class="resumen-contenido">
        <h3>Resumen de tu cita</h3>

        <p><strong>Paquete:</strong> <span id="rPaquete"></span></p>
        <p><strong>Opción:</strong> <span id="rOpcion"></span></p>
        <p><strong>Precio:</strong> $<span id="rPrecio"></span></p>
        <p><strong>Fecha:</strong> <span id="rFecha"></span></p>
        <p><strong>Hora:</strong> <span id="rHora"></span></p>

        <div class="d-flex justify-content-center gap-3 mt-4">
            <button type="button" class="btn btn-secondary" onclick="cerrarResumen()">
                Regresar
            </button>

            <button type="button" class="btn btn-success" onclick="document.getElementById('enviarCita').click();">
                Confirmo cita
            </button>
        </div>
    </div>
</div>

<script>
let paqueteSeleccionado = "";
flatpickr("#fecha", {
    dateFormat: "Y-m-d",
    minDate: new Date().fp_incr(1)
});
function seleccionarPaquete(card, paquete){
    document.querySelectorAll('.card-paquete').forEach(c => c.classList.remove('active'));

    card.classList.add('active');
    card.querySelector('input[type="radio"]').checked = true;

    paqueteSeleccionado = paquete;

    document.getElementById("precio").value = "";
    document.getElementById("opcion").value = "";
    document.getElementById("fecha").value = "";
    document.getElementById("horas").innerHTML = "";
    document.getElementById("hora").value = "";
}

function seleccionarOpcion(select){
    let opcionSeleccionada = select.options[select.selectedIndex];
    let card = select.closest('.card-paquete');

    // Al elegir una opción también se selecciona automáticamente el paquete.
    if(card){
        document.querySelectorAll('.card-paquete').forEach(c => c.classList.remove('active'));
        card.classList.add('active');

        let radio = card.querySelector('input[type="radio"]');
        if(radio){
            radio.checked = true;
            paqueteSeleccionado = radio.value;
        }
    }

    document.getElementById("fecha").value = "";
    document.getElementById("horas").innerHTML = "";
    document.getElementById("hora").value = "";

    if(opcionSeleccionada.value === ""){
        document.getElementById("precio").value = "";
        document.getElementById("opcion").value = "";
        return;
    }

    document.getElementById("precio").value = opcionSeleccionada.dataset.precio;
    document.getElementById("opcion").value = opcionSeleccionada.dataset.opcion;
}

document.getElementById("fecha").addEventListener("change", function(){

    if(paqueteSeleccionado === ""){
        alert("Primero selecciona un paquete");
        this.value = "";
        return;
    }

    fetch("horas_disponibles.php?fecha=" + this.value + "&paquete=" + encodeURIComponent(paqueteSeleccionado))
    .then(r => r.json())
    .then(data => {

        let cont = document.getElementById("horas");
        cont.innerHTML = "";
        document.getElementById("hora").value = "";

        if(data.length === 0){
            cont.innerHTML = "<p class='text-danger mt-2'>No hay horarios disponibles para este día.</p>";
            return;
        }

        data.forEach(h => {
            cont.innerHTML += `
                <span class="hora" onclick="setHora('${h}', this)">
                    ${h}
                </span>`;
        });

    });
});

function setHora(h, el){
    document.querySelectorAll('.hora').forEach(x => x.classList.remove('active'));
    el.classList.add('active');
    document.getElementById("hora").value = h;
}

function mostrarResumen(){
    let paquete = paqueteSeleccionado;
    let opcion = document.getElementById("opcion").value;
    let precio = document.getElementById("precio").value;
    let fecha = document.getElementById("fecha").value;
    let hora = document.getElementById("hora").value;

    if(paquete === "" || opcion === "" || precio === "" || fecha === "" || hora === ""){
        alert("Selecciona paquete, opción, fecha y hora antes de confirmar.");
        return;
    }

    document.getElementById("rPaquete").innerText = paquete;
    document.getElementById("rOpcion").innerText = opcion;
    document.getElementById("rPrecio").innerText = precio;
    document.getElementById("rFecha").innerText = fecha;
    document.getElementById("rHora").innerText = hora;

    document.getElementById("resumenCita").style.display = "flex";
}

function cerrarResumen(){
    document.getElementById("resumenCita").style.display = "none";
}
</script>

</body>
</html>