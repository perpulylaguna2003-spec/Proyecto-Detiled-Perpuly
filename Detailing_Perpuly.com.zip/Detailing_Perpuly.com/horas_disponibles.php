<?php
session_start();
date_default_timezone_set('America/Mazatlan');

require_once "Conexion.php";

header('Content-Type: application/json');

if (!isset($_GET['fecha']) || !isset($_GET['paquete'])) {
    echo json_encode([]);
    exit;
}

$fecha = $_GET['fecha'];
$paquete = $_GET['paquete'];

/* VALIDAR QUE LA FECHA SEA MÍNIMO MAÑANA */
$fechaMinima = date('Y-m-d', strtotime('+1 day'));

if ($fecha < $fechaMinima) {
    echo json_encode([]);
    exit;
}

/* OBTENER DURACIÓN DESDE MYSQL */
$sqlDuracion = "SELECT duracion FROM paquete WHERE nombre = ?";
$stmtDuracion = $connect->prepare($sqlDuracion);
$stmtDuracion->bind_param("s", $paquete);
$stmtDuracion->execute();

$resDuracion = $stmtDuracion->get_result();
$datosDuracion = $resDuracion->fetch_assoc();

if (!$datosDuracion) {
    echo json_encode([]);
    exit;
}

$duracion = (int)$datosDuracion['duracion']; // minutos

$horaApertura = 9;
$horaCierre = 19;

$disponibles = [];

/* 
   IMPORTANTE:
   Solo las citas AGENDADAS bloquean horarios.
   Las citas CANCELADAS o REALIZADAS ya no ocupan espacio.
*/
$sql = "SELECT hora_inicio, hora_fin 
        FROM citas 
        WHERE fecha = ? 
        AND estado = 'Agendada'";

$stmt = $connect->prepare($sql);
$stmt->bind_param("s", $fecha);
$stmt->execute();

$resultado = $stmt->get_result();

$citas = [];

while ($fila = $resultado->fetch_assoc()) {
    $citas[] = $fila;
}

/* GENERAR HORARIOS */
for ($h = $horaApertura; $h < $horaCierre; $h++) {

    $hora_inicio = str_pad($h, 2, "0", STR_PAD_LEFT) . ":00:00";

    $inicio = strtotime($hora_inicio);
    $fin = strtotime("+$duracion minutes", $inicio);

    /*
       El negocio cierra a las 7:00 PM.
       Por eso la cita debe terminar máximo a las 19:00:00.
    */
    if ($fin > strtotime("19:00:00")) {
        continue;
    }

    $ocupada = false;

    foreach ($citas as $cita) {

        $ini_exist = strtotime($cita['hora_inicio']);
        $fin_exist = strtotime($cita['hora_fin']);

        if ($inicio < $fin_exist && $fin > $ini_exist) {
            $ocupada = true;
            break;
        }
    }

    if (!$ocupada) {
        $disponibles[] = substr($hora_inicio, 0, 5);
    }
}

echo json_encode($disponibles);
?>
