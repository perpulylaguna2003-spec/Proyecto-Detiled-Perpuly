<?php
session_start();
require_once 'Conexion.php';

$correo = trim($_POST["correo"] ?? '');
$password = $_POST["password"] ?? '';

$consulta = $connect->prepare("SELECT * FROM usuarios WHERE correo = ? LIMIT 1");
$consulta->bind_param("s", $correo);
$consulta->execute();

$res = $consulta->get_result();
$user = $res->fetch_assoc();

if (!$user) {
    header('Location: Index.php?error=1');
    exit;
}

if (!password_verify($password, $user['password'])) {
    header('Location: Index.php?error=1');
    exit;
}

if ($user['estado'] == 'Bloqueado') {
    header('Location: Index.php?bloqueado=1');
    exit;
}

$_SESSION['id'] = $user['id'];
$_SESSION['usuario'] = $user['nombre'];
$_SESSION['rol'] = $user['rol'];

if ($user['rol'] == 'admin') {
    header('Location: Menu_admin.php');
    exit;
} else {
    header('Location: paquetes.php');
    exit;
}
?>